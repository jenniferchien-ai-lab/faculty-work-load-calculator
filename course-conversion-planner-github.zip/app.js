(function () {
  "use strict";

  const root = document.getElementById("planner-root");
  if (!root) return;

  /*
   * ESTIMATION_CONFIG contains every adjustable planning assumption.
   * These starter values are intentionally conservative and should be
   * calibrated against completed course-conversion projects before the
   * planner is presented as an institutional estimate.
   */
  const ESTIMATION_CONFIG = {
    courseBaseHours: 6,
    hoursPerModule: 2.2,
    courseTypeFactor: {
      lecture: 1,
      seminar: 1.05,
      project: 1.15,
      lab: 1.45,
      mixed: 1.2,
      unsure: 1.15,
    },
    materialHours: {
      reuse: 0.25,
      revise: 1.5,
      create: 4,
      unsure: 2,
      na: 0,
    },
    currentActivityHours: {
      lecture: 2,
      discussion: 3,
      groups: 5,
      problems: 4,
      cases: 4,
      hands_on: 8,
      demonstration: 6,
      lab: 12,
      presentations: 5,
      feedback: 4,
      quizzes: 3,
      unsure: 5,
      other: 3,
    },
    onlineActivityHours: {
      content: 0.3,
      discussion: 0.7,
      assignments: 1,
      collaboration: 1.8,
      practice: 1.2,
      cases: 1.4,
      feedback: 0.7,
      quizzes: 0.8,
      presentations: 1.2,
      interactive: 2,
      simulation: 4,
      game: 4,
      lab: 5,
      unsure: 1.3,
    },
    activityOccurrences: {
      few: (modules) => Math.min(3, Math.max(1, modules)),
      module: (modules) => modules,
      several: (modules) => modules * 2,
      unsure: (modules) => Math.max(3, Math.round(modules * 0.75)),
    },
    videoCount: {
      intro: () => 1,
      few: () => 3,
      module: (modules) => modules,
      several: (modules) => Math.ceil(modules * 2.25),
      none: () => 0,
      unsure: (modules) => Math.max(3, Math.round(modules * 0.65)),
    },
    videoHoursByLength: {
      short: 0.9,
      medium: 1.4,
      long: 2.4,
      extra_long: 3.8,
      unsure: 1.8,
    },
    videoTypeFactor: {
      slides: 1,
      explanation: 0.85,
      screen: 1,
      physical: 1.7,
      camera: 1.15,
      interview: 1.8,
      location: 2.15,
      unsure: 1.25,
    },
    panoptoComfortFactor: {
      independent: 0.9,
      guidance: 1.05,
      substantial: 1.25,
      new: 1.3,
      unsure: 1.18,
    },
    visualHours: {
      none: 0,
      few: 4,
      several: 16,
      unsure: 6,
    },
    interactionHours: {
      canvas: 0,
      clickable: 10,
      scenario: 18,
      simulation: 35,
      game: 35,
      unsure: 8,
    },
    instructionalDesignerFactor: {
      yes: 0.78,
      no: 1.12,
      unsure: 1,
    },
    facultyRange: { low: 0.8, high: 1.25 },
    weeklyCapacity: {
      less2: [1, 2],
      two4: [2, 4],
      five8: [5, 8],
      more8: [9, 12],
    },
  };

  const steps = [
    {
      key: "course",
      label: "About the course",
      kicker: "Step 1",
      title: "Start with the course you already teach",
      description: "A few basics help us interpret the rest of your answers.",
    },
    {
      key: "current",
      label: "Current class",
      kicker: "Step 2",
      title: "What happens during class now?",
      description: "Choose the experiences that are important in your in-person course.",
    },
    {
      key: "materials",
      label: "Existing materials",
      kicker: "Step 3",
      title: "What do you already have?",
      description: "You do not need polished materials. Tell us what is available and what still needs work.",
    },
    {
      key: "video",
      label: "Video and Panopto",
      kicker: "Step 4",
      title: "How might you use video?",
      description: "Panopto works well for straightforward faculty-created recordings. Your answers will help identify when other support may be useful.",
    },
    {
      key: "learning",
      label: "Online learning",
      kicker: "Step 5",
      title: "What should students do online?",
      description: "Focus on the student experience. The planner will interpret the development work behind it.",
    },
    {
      key: "support",
      label: "Support and time",
      kicker: "Step 6",
      title: "Who can help?",
      description: "It is fine if you are unsure. Your instructional designer can help confirm what support is available.",
    },
    {
      key: "results",
      label: "Planning summary",
      kicker: "Your results",
      title: "A starting point for your course conversion",
      description: "Use this summary to begin a conversation with your instructional designer.",
    },
  ];

  const materialItems = [
    ["syllabus", "Syllabus and course schedule"],
    ["course_objectives", "Course learning objectives"],
    ["module_objectives", "Module or weekly learning objectives"],
    ["slides", "Presentation slides"],
    ["notes", "Lecture notes"],
    ["readings", "Readings or instructional content"],
    ["assignments", "Assignments"],
    ["discussions", "Discussion prompts"],
    ["quizzes", "Quizzes or exams"],
    ["rubrics", "Rubrics or grading criteria"],
    ["canvas", "Existing Canvas content"],
    ["videos", "Existing video recordings"],
  ];

  const currentActivities = [
    ["lecture", "Listen to lectures or presentations"],
    ["discussion", "Participate in class discussions"],
    ["groups", "Work in small groups"],
    ["problems", "Practice solving problems"],
    ["cases", "Analyze examples, cases, or scenarios"],
    ["hands_on", "Complete hands-on activities"],
    ["demonstration", "Watch demonstrations"],
    ["lab", "Participate in labs, studio work, or simulations"],
    ["presentations", "Give presentations"],
    ["feedback", "Receive feedback from the instructor"],
    ["quizzes", "Complete quizzes or exams"],
    ["unsure", "I’m not sure how these activities will translate online"],
    ["other", "Other"],
  ];

  const videoTypes = [
    ["slides", "Narrated presentation slides"],
    ["explanation", "A short explanation or course update"],
    ["screen", "A demonstration on my computer"],
    ["physical", "A physical or hands-on demonstration"],
    ["camera", "A presentation recorded on camera"],
    ["interview", "An interview or conversation with another person"],
    ["location", "A recording in a classroom, lab, studio, or other location"],
    ["unsure", "I’m not sure"],
  ];

  const onlineActivities = [
    ["content", "Read or view course content"],
    ["discussion", "Participate in discussions"],
    ["assignments", "Complete individual assignments"],
    ["collaboration", "Work with classmates"],
    ["practice", "Practice skills or solve problems"],
    ["cases", "Analyze cases or scenarios"],
    ["feedback", "Receive feedback"],
    ["quizzes", "Complete quizzes or exams"],
    ["presentations", "Make presentations"],
    ["interactive", "Explore interactive examples"],
    ["simulation", "Participate in a simulation"],
    ["game", "Try a game-like learning activity"],
    ["lab", "Complete a lab, studio, demonstration, or clinical activity"],
    ["unsure", "I’m not sure"],
  ];

  const supportRoles = [
    ["id", "Instructional designer", "Helps organize the course and adapt content, activities, and assessments."],
    ["video", "Videographer", "Helps record and edit more involved video productions."],
    ["graphic", "Graphic designer", "Creates original diagrams, illustrations, and visual materials."],
    ["interactive", "Interactivity designer", "Develops custom scenarios, simulations, games, or interactive practice."],
  ];

  const defaultAnswers = () => ({
    courseTitle: "",
    weeks: "",
    modules: "",
    delivery: "",
    courseType: "",
    currentActivities: [],
    currentOther: "",
    materials: {},
    videoCadence: "",
    videoTypes: [],
    panoptoComfort: "",
    videoLength: "",
    onlineActivities: [],
    activityFrequency: "",
    visuals: "",
    interactions: [],
    support: {},
    availability: "",
  });

  const state = {
    step: 0,
    answers: defaultAnswers(),
    errors: [],
    results: null,
  };

  let lastFocusedElement = null;

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function checked(name, value) {
    return Array.isArray(state.answers[name]) && state.answers[name].includes(value) ? " checked" : "";
  }

  function selected(value, expected) {
    return value === expected ? " selected" : "";
  }

  function radioChecked(value, expected) {
    return value === expected ? " checked" : "";
  }

  function render() {
    const step = steps[state.step];
    const progress = Math.round(((state.step + 1) / steps.length) * 100);
    const showIntro = state.step === 0;

    root.innerHTML = `
      <a class="skip-link" href="#planner-content">Skip to planner</a>
      <div class="site-shell">
        <header class="site-header">
          <div class="header-inner">
            <div class="brand" aria-label="Course Conversion Planner">
              <span class="brand-mark" aria-hidden="true">↗</span>
              <span class="brand-text">
                <span class="brand-title">Course Conversion Planner</span>
                <span class="brand-subtitle">From in-person teaching to online learning</span>
              </span>
            </div>
            <span class="privacy-note"><span class="privacy-dot" aria-hidden="true"></span>No responses are saved</span>
          </div>
        </header>

        <div class="app-layout">
          ${showIntro ? renderIntro() : ""}
          <div class="planner-frame">
            ${renderProgress(progress)}
            <section class="step-card" id="planner-content" aria-labelledby="step-title">
              <div class="step-heading">
                <p class="step-kicker">${escapeHtml(step.kicker)}</p>
                <h2 id="step-title" tabindex="-1">${escapeHtml(step.title)}</h2>
                <p>${escapeHtml(step.description)}</p>
              </div>
              <div class="step-body">
                <div class="error-summary" id="error-summary" role="alert" tabindex="-1">${renderErrors()}</div>
                ${renderStep()}
              </div>
              ${renderActions()}
            </section>
          </div>
        </div>

        <footer class="site-footer">
          This planner provides a preliminary estimate for conversation and planning. It is not an official workload determination or production commitment.
        </footer>
      </div>

      <div class="dialog-backdrop" id="reset-dialog" role="presentation" hidden>
        <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="reset-title" aria-describedby="reset-description">
          <h2 id="reset-title">Start over?</h2>
          <p id="reset-description">This will clear all of your responses and return to the beginning.</p>
          <div class="dialog-actions">
            <button class="button button-secondary" type="button" data-action="cancel-reset">Keep my responses</button>
            <button class="button button-danger" type="button" data-action="confirm-reset">Clear and start over</button>
          </div>
        </div>
      </div>
      <div class="visually-hidden" id="status-message" aria-live="polite"></div>
    `;

    bindEvents();
  }

  function renderIntro() {
    return `
      <section class="intro-grid" aria-labelledby="page-title">
        <div class="intro-copy">
          <p class="eyebrow">A guided planning conversation</p>
          <h1 id="page-title">Bring your course online with a clearer starting point.</h1>
          <p>Answer practical questions about the course you already teach. You will receive an estimated faculty effort range, a Panopto approach, and topics to discuss with your instructional designer.</p>
        </div>
        <aside class="intro-card" aria-label="What to expect">
          <div>
            <h2>What to expect</h2>
            <ul>
              <li>6 short sections</li>
              <li>About 8–10 minutes</li>
              <li>No design jargon required</li>
            </ul>
          </div>
          <small>Your answers stay in this browser only while the page is open.</small>
        </aside>
      </section>
    `;
  }

  function renderProgress(progress) {
    return `
      <aside class="progress-panel" aria-label="Planner progress">
        <div class="progress-label"><span>Progress</span><span>${progress}%</span></div>
        <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}" aria-label="Planner completion">
          <div class="progress-fill" style="width:${progress}%"></div>
        </div>
        <ol class="step-list">
          ${steps
            .map((item, index) => {
              const className = index === state.step ? "is-current" : index < state.step ? "is-complete" : "";
              const current = index === state.step ? ' aria-current="step"' : "";
              return `<li class="${className}" data-step="${index + 1}"${current}>${escapeHtml(item.label)}</li>`;
            })
            .join("")}
        </ol>
      </aside>
    `;
  }

  function renderErrors() {
    if (!state.errors.length) return "";
    return `<strong>Please complete this section.</strong><ul>${state.errors.map((error) => `<li>${escapeHtml(error)}</li>`).join("")}</ul>`;
  }

  function renderStep() {
    switch (steps[state.step].key) {
      case "course":
        return renderCourseStep();
      case "current":
        return renderCurrentStep();
      case "materials":
        return renderMaterialsStep();
      case "video":
        return renderVideoStep();
      case "learning":
        return renderLearningStep();
      case "support":
        return renderSupportStep();
      case "results":
        return renderResultsStep();
      default:
        return "";
    }
  }

  function renderCourseStep() {
    const a = state.answers;
    return `
      <div class="field-grid">
        <div class="question-block">
          <label class="question-label" for="courseTitle">Course title <span class="question-help">(optional)</span></label>
          <input class="text-input" id="courseTitle" name="courseTitle" type="text" value="${escapeHtml(a.courseTitle)}" autocomplete="off" />
        </div>
        <div class="question-block">
          <label class="question-label" for="weeks">How many weeks long is the course? <span class="required-marker" aria-hidden="true">*</span></label>
          <input class="number-input" id="weeks" name="weeks" type="number" min="1" max="30" inputmode="numeric" value="${escapeHtml(a.weeks)}" required />
        </div>
        <div class="question-block">
          <label class="question-label" for="modules">Approximately how many modules or major units will it contain? <span class="required-marker" aria-hidden="true">*</span></label>
          <input class="number-input" id="modules" name="modules" type="number" min="1" max="40" inputmode="numeric" value="${escapeHtml(a.modules)}" required />
        </div>
      </div>

      ${radioQuestion(
        "delivery",
        "How will the online course be delivered?",
        [
          ["async", "Mostly asynchronous", "Students complete work on their own schedule."],
          ["mixed", "A combination", "Asynchronous work and scheduled online meetings."],
          ["sync", "Mostly scheduled online meetings", "Most learning happens together at set times."],
          ["unsure", "I’m not sure", "Your instructional designer can help you decide."],
        ],
        a.delivery
      )}

      ${radioQuestion(
        "courseType",
        "Which description best matches the course?",
        [
          ["lecture", "Primarily lectures and content presentations", ""],
          ["seminar", "Primarily discussion and seminar activities", ""],
          ["project", "Primarily projects or applied assignments", ""],
          ["lab", "Includes labs, demonstrations, studio work, simulations, or clinical activities", ""],
          ["mixed", "A combination of these", ""],
          ["unsure", "I’m not sure", ""],
        ],
        a.courseType
      )}
    `;
  }

  function renderCurrentStep() {
    const a = state.answers;
    return `
      <fieldset class="question-group">
        <legend>What do students typically do during in-person class meetings? <span class="required-marker" aria-hidden="true">*</span></legend>
        <p class="question-help">Select all that apply. Choose what matters to the learning experience, even if you do not yet know how it will work online.</p>
        <div class="choice-grid">
          ${currentActivities.map(([value, label]) => checkboxCard("currentActivities", value, label, "")).join("")}
        </div>
      </fieldset>
      <div class="conditional-panel" ${a.currentActivities.includes("other") ? "" : "hidden"}>
        <label class="question-label" for="currentOther">What else do students do?</label>
        <input class="other-input" id="currentOther" name="currentOther" type="text" value="${escapeHtml(a.currentOther)}" />
      </div>
    `;
  }

  function renderMaterialsStep() {
    const a = state.answers;
    return `
      <div class="callout"><strong>Choose the closest answer.</strong> “Needs revision” can mean anything from small updates to significant reworking. The estimate uses a range to account for that difference.</div>
      <div class="material-list" role="group" aria-label="Existing course materials">
        ${materialItems
          .map(
            ([key, label]) => `
              <div class="material-row">
                <label class="material-label" for="material-${key}">${escapeHtml(label)} <span class="required-marker" aria-hidden="true">*</span></label>
                <select class="select-input" id="material-${key}" name="material.${key}">
                  <option value="">Choose one</option>
                  <option value="reuse"${selected(a.materials[key], "reuse")}>I have this and can probably reuse it</option>
                  <option value="revise"${selected(a.materials[key], "revise")}>I have this, but it needs revision</option>
                  <option value="create"${selected(a.materials[key], "create")}>I will need to create it</option>
                  <option value="unsure"${selected(a.materials[key], "unsure")}>I’m not sure</option>
                  <option value="na"${selected(a.materials[key], "na")}>Not applicable</option>
                </select>
              </div>
            `
          )
          .join("")}
      </div>
    `;
  }

  function renderVideoStep() {
    const a = state.answers;
    const usingVideo = a.videoCadence && a.videoCadence !== "none";
    return `
      <div class="callout"><strong>Panopto is the starting point.</strong> It can be used for short presentations, narrated slides, demonstrations, and screen recordings. More involved productions may benefit from a videographer.</div>
      ${radioQuestion(
        "videoCadence",
        "How often do you think students will need an instructor-created video?",
        [
          ["intro", "Only a welcome or course-introduction video", ""],
          ["few", "A few videos during the course", ""],
          ["module", "About one video per module", ""],
          ["several", "More than one video per module", ""],
          ["none", "I do not plan to create videos", ""],
          ["unsure", "I’m not sure", ""],
        ],
        a.videoCadence
      )}
      <div class="conditional-panel" ${usingVideo ? "" : "hidden"}>
        <fieldset class="question-group">
          <legend>What would you most likely record? <span class="required-marker" aria-hidden="true">*</span></legend>
          <p class="question-help">Select all that apply.</p>
          <div class="choice-grid">
            ${videoTypes.map(([value, label]) => checkboxCard("videoTypes", value, label, "")).join("")}
          </div>
        </fieldset>

        ${radioQuestion(
          "panoptoComfort",
          "How comfortable are you with using Panopto?",
          [
            ["independent", "I can record and manage videos independently", ""],
            ["guidance", "I could use Panopto with some initial guidance", ""],
            ["substantial", "I would need substantial help", ""],
            ["new", "I have not used Panopto", ""],
            ["unsure", "I’m not sure", ""],
          ],
          a.panoptoComfort
        )}

        ${radioQuestion(
          "videoLength",
          "Approximately how long do you expect most videos to be?",
          [
            ["short", "Less than 5 minutes", ""],
            ["medium", "5–10 minutes", ""],
            ["long", "11–20 minutes", ""],
            ["extra_long", "Longer than 20 minutes", ""],
            ["unsure", "I’m not sure", ""],
          ],
          a.videoLength
        )}
      </div>
    `;
  }

  function renderLearningStep() {
    const a = state.answers;
    return `
      <fieldset class="question-group">
        <legend>Which experiences would you like students to have online? <span class="required-marker" aria-hidden="true">*</span></legend>
        <p class="question-help">Select all that apply. You do not need to know which technology would be used.</p>
        <div class="choice-grid">
          ${onlineActivities.map(([value, label]) => checkboxCard("onlineActivities", value, label, "")).join("")}
        </div>
      </fieldset>

      ${radioQuestion(
        "activityFrequency",
        "How often will students complete these kinds of activities?",
        [
          ["few", "A few times during the course", ""],
          ["module", "About once per module", ""],
          ["several", "Several times per module", ""],
          ["unsure", "I’m not sure", ""],
        ],
        a.activityFrequency
      )}

      ${radioQuestion(
        "visuals",
        "Will students need diagrams, illustrations, or other visuals that do not already exist?",
        [
          ["none", "No", ""],
          ["few", "A few simple visuals", ""],
          ["several", "Several original diagrams or illustrations", ""],
          ["unsure", "I’m not sure", ""],
        ],
        a.visuals
      )}

      <fieldset class="question-group">
        <legend>Would you like students to use any of the following? <span class="required-marker" aria-hidden="true">*</span></legend>
        <p class="question-help">Select all that apply.</p>
        <div class="choice-grid">
          ${[
            ["canvas", "Standard Canvas activities", "Discussions, quizzes, assignments, and similar tools."],
            ["clickable", "Clickable practice activities", "Students make selections and receive feedback."],
            ["scenario", "Interactive scenarios", "Students make choices within a realistic situation."],
            ["simulation", "Simulations", "Students practice within a modeled process or environment."],
            ["game", "Game-like learning activities", "Activities that use challenges, progress, or playful structures."],
            ["unsure", "I’m not sure", "Your instructional designer can help identify an appropriate approach."],
          ]
            .map(([value, label, description]) => checkboxCard("interactions", value, label, description))
            .join("")}
        </div>
      </fieldset>
    `;
  }

  function renderSupportStep() {
    const a = state.answers;
    return `
      <fieldset class="question-group">
        <legend>Who will be available to help you convert the course? <span class="required-marker" aria-hidden="true">*</span></legend>
        <p class="question-help">Choose “I’m not sure” when you do not know. The result will suggest what to discuss with your instructional designer.</p>
        <div class="support-list">
          ${supportRoles
            .map(
              ([key, title, description]) => `
                <div class="support-row">
                  <div class="support-copy" id="support-${key}-label">
                    <strong>${escapeHtml(title)}</strong>
                    <span>${escapeHtml(description)}</span>
                  </div>
                  <div class="inline-radios" role="radiogroup" aria-labelledby="support-${key}-label">
                    ${inlineRadio(`support.${key}`, "yes", "Yes", a.support[key])}
                    ${inlineRadio(`support.${key}`, "no", "No", a.support[key])}
                    ${inlineRadio(`support.${key}`, "unsure", "I’m not sure", a.support[key])}
                  </div>
                </div>
              `
            )
            .join("")}
        </div>
      </fieldset>

      ${radioQuestion(
        "availability",
        "How much time can you typically set aside each week to work on the course conversion?",
        [
          ["less2", "Less than 2 hours", ""],
          ["two4", "2–4 hours", ""],
          ["five8", "5–8 hours", ""],
          ["more8", "More than 8 hours", ""],
          ["varies", "My availability varies", ""],
          ["unsure", "I’m not sure", ""],
        ],
        a.availability
      )}
    `;
  }

  function radioQuestion(name, legend, options, currentValue) {
    return `
      <fieldset class="question-group">
        <legend>${escapeHtml(legend)} <span class="required-marker" aria-hidden="true">*</span></legend>
        <div class="choice-grid">
          ${options
            .map(
              ([value, title, description]) => `
                <label class="choice-card">
                  <input type="radio" name="${escapeHtml(name)}" value="${escapeHtml(value)}"${radioChecked(currentValue, value)} />
                  <span class="choice-copy">
                    <span class="choice-title">${escapeHtml(title)}</span>
                    ${description ? `<span class="choice-description">${escapeHtml(description)}</span>` : ""}
                  </span>
                </label>
              `
            )
            .join("")}
        </div>
      </fieldset>
    `;
  }

  function checkboxCard(name, value, title, description) {
    return `
      <label class="choice-card">
        <input type="checkbox" name="${escapeHtml(name)}" value="${escapeHtml(value)}"${checked(name, value)} />
        <span class="choice-copy">
          <span class="choice-title">${escapeHtml(title)}</span>
          ${description ? `<span class="choice-description">${escapeHtml(description)}</span>` : ""}
        </span>
      </label>
    `;
  }

  function inlineRadio(name, value, label, currentValue) {
    return `
      <label class="inline-radio">
        <input type="radio" name="${escapeHtml(name)}" value="${escapeHtml(value)}"${radioChecked(currentValue, value)} />
        <span>${escapeHtml(label)}</span>
      </label>
    `;
  }

  function renderActions() {
    const isFirst = state.step === 0;
    const isResults = state.step === steps.length - 1;
    return `
      <div class="step-actions">
        <button class="button button-tertiary" type="button" data-action="open-reset">Start over</button>
        <div class="action-group">
          ${!isFirst ? `<button class="button button-secondary" type="button" data-action="back">Back</button>` : ""}
          ${
            isResults
              ? `<button class="button button-secondary" type="button" data-action="edit">Edit responses</button><button class="button button-primary" type="button" data-action="print">Print results</button>`
              : `<button class="button button-primary" type="button" data-action="next">${state.step === steps.length - 2 ? "View results" : "Continue"}</button>`
          }
        </div>
      </div>
    `;
  }

  function validateStep() {
    const a = state.answers;
    const key = steps[state.step].key;
    const errors = [];

    if (key === "course") {
      if (!a.weeks || Number(a.weeks) < 1 || Number(a.weeks) > 30) errors.push("Enter a course length between 1 and 30 weeks.");
      if (!a.modules || Number(a.modules) < 1 || Number(a.modules) > 40) errors.push("Enter between 1 and 40 modules or major units.");
      if (!a.delivery) errors.push("Choose how the online course will be delivered.");
      if (!a.courseType) errors.push("Choose the description that best matches the course.");
    }

    if (key === "current" && !a.currentActivities.length) {
      errors.push("Choose at least one activity that happens during the current course.");
    }

    if (key === "materials") {
      const missing = materialItems.filter(([itemKey]) => !a.materials[itemKey]);
      if (missing.length) errors.push(`Choose an answer for each material (${missing.length} remaining).`);
    }

    if (key === "video") {
      if (!a.videoCadence) errors.push("Choose how often students may need an instructor-created video.");
      if (a.videoCadence && a.videoCadence !== "none") {
        if (!a.videoTypes.length) errors.push("Choose at least one type of video you may record.");
        if (!a.panoptoComfort) errors.push("Choose how comfortable you are with Panopto.");
        if (!a.videoLength) errors.push("Choose an approximate video length.");
      }
    }

    if (key === "learning") {
      if (!a.onlineActivities.length) errors.push("Choose at least one experience for students online.");
      if (!a.activityFrequency) errors.push("Choose how often students may complete these activities.");
      if (!a.visuals) errors.push("Choose an answer about diagrams and visuals.");
      if (!a.interactions.length) errors.push("Choose at least one type of activity or select “I’m not sure.”");
    }

    if (key === "support") {
      const missingRoles = supportRoles.filter(([role]) => !a.support[role]);
      if (missingRoles.length) errors.push("Choose Yes, No, or I’m not sure for each support role.");
      if (!a.availability) errors.push("Choose the amount of time you can typically set aside each week.");
    }

    state.errors = errors;
    return errors.length === 0;
  }

  function bindEvents() {
    root.querySelectorAll("input, select").forEach((control) => {
      control.addEventListener("input", handleInput);
      control.addEventListener("change", handleChange);
    });

    root.querySelectorAll("[data-action]").forEach((button) => {
      button.addEventListener("click", handleAction);
    });

  }

  function handleInput(event) {
    const target = event.target;
    if (!target.name || target.type === "radio" || target.type === "checkbox") return;
    setAnswer(target.name, target.value);
  }

  function handleChange(event) {
    const target = event.target;
    if (!target.name) return;

    if (target.type === "checkbox") {
      updateCheckboxAnswer(target.name, target.value, target.checked);
      render();
      focusAfterRender(target.name, target.value);
      return;
    }

    setAnswer(target.name, target.value);
    if (target.type === "radio" || target.tagName === "SELECT") {
      const shouldRender = target.name === "videoCadence" || target.name.startsWith("support.");
      if (shouldRender) {
        render();
        focusAfterRender(target.name, target.value);
      }
    }
  }

  function setAnswer(name, value) {
    if (name.startsWith("material.")) {
      state.answers.materials[name.split(".")[1]] = value;
    } else if (name.startsWith("support.")) {
      state.answers.support[name.split(".")[1]] = value;
    } else {
      state.answers[name] = value;
    }
  }

  function updateCheckboxAnswer(name, value, isChecked) {
    let values = [...(state.answers[name] || [])];
    const exclusive = value === "unsure";

    if (isChecked) {
      if (exclusive) {
        values = [value];
      } else {
        values = values.filter((item) => item !== "unsure");
        if (!values.includes(value)) values.push(value);
      }
    } else {
      values = values.filter((item) => item !== value);
    }

    state.answers[name] = values;
  }

  function focusAfterRender(name, value) {
    requestAnimationFrame(() => {
      const selector = `[name="${CSS.escape(name)}"][value="${CSS.escape(value)}"]`;
      const control = root.querySelector(selector);
      if (control) control.focus();
    });
  }

  function handleAction(event) {
    const action = event.currentTarget.dataset.action;
    if (action === "next") goNext();
    if (action === "back") goBack();
    if (action === "edit") goToStep(0);
    if (action === "print") window.print();
    if (action === "open-reset") openResetDialog(event.currentTarget);
    if (action === "cancel-reset") closeResetDialog();
    if (action === "confirm-reset") resetPlanner();
  }

  function goNext() {
    if (!validateStep()) {
      render();
      requestAnimationFrame(() => root.querySelector("#error-summary")?.focus());
      return;
    }

    state.errors = [];
    if (state.step === steps.length - 2) {
      state.results = calculateResults(state.answers);
    }
    goToStep(Math.min(state.step + 1, steps.length - 1));
  }

  function goBack() {
    state.errors = [];
    goToStep(Math.max(0, state.step - 1));
  }

  function goToStep(index) {
    state.step = index;
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
    requestAnimationFrame(() => root.querySelector("#step-title")?.focus?.());
  }

  function openResetDialog(trigger) {
    lastFocusedElement = trigger;
    const dialog = root.querySelector("#reset-dialog");
    dialog.hidden = false;
    requestAnimationFrame(() => dialog.querySelector('[data-action="cancel-reset"]')?.focus());
  }

  function closeResetDialog() {
    const dialog = root.querySelector("#reset-dialog");
    if (dialog) dialog.hidden = true;
    if (lastFocusedElement) lastFocusedElement.focus();
  }

  function handleDialogEscape(event) {
    const dialog = root.querySelector("#reset-dialog");
    if (!dialog || dialog.hidden) return;

    if (event.key === "Escape") {
      closeResetDialog();
      return;
    }

    if (event.key === "Tab") {
      const focusable = [...dialog.querySelectorAll("button:not([disabled])")];
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
  }

  function resetPlanner() {
    state.step = 0;
    state.answers = defaultAnswers();
    state.errors = [];
    state.results = null;
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function calculateResults(a) {
    const config = ESTIMATION_CONFIG;
    const modules = Math.max(1, Number(a.modules) || 1);
    const courseFactor = config.courseTypeFactor[a.courseType] || 1.15;
    const idStatus = a.support.id || "unsure";
    const idFactor = config.instructionalDesignerFactor[idStatus];

    let coreHours = (config.courseBaseHours + modules * config.hoursPerModule) * courseFactor;

    const materialCounts = { reuse: 0, revise: 0, create: 0, unsure: 0, na: 0 };
    let materialHours = 0;
    Object.values(a.materials).forEach((status) => {
      if (materialCounts[status] !== undefined) materialCounts[status] += 1;
      materialHours += config.materialHours[status] || 0;
    });

    let adaptationHours = 0;
    a.currentActivities.forEach((activity) => {
      adaptationHours += config.currentActivityHours[activity] || 0;
    });

    const occurrenceFn = config.activityOccurrences[a.activityFrequency] || config.activityOccurrences.unsure;
    const occurrences = occurrenceFn(modules);
    let onlineHours = 0;
    a.onlineActivities.forEach((activity) => {
      onlineHours += (config.onlineActivityHours[activity] || 0) * occurrences;
    });

    const designFacultyHours = (coreHours + materialHours + adaptationHours + onlineHours) * idFactor;

    let videoFacultyHours = 0;
    const hasVideo = a.videoCadence && a.videoCadence !== "none";
    const complexVideoTypes = ["physical", "interview", "location"];
    const hasComplexVideo = a.videoTypes.some((type) => complexVideoTypes.includes(type));
    if (hasVideo) {
      const countFn = config.videoCount[a.videoCadence] || config.videoCount.unsure;
      const videoCount = countFn(modules);
      const lengthHours = config.videoHoursByLength[a.videoLength] || config.videoHoursByLength.unsure;
      const typeFactor = Math.max(...a.videoTypes.map((type) => config.videoTypeFactor[type] || 1.2), 1);
      const comfortFactor = config.panoptoComfortFactor[a.panoptoComfort] || config.panoptoComfortFactor.unsure;
      const videoSupport = a.support.video || "unsure";

      if (hasComplexVideo && videoSupport === "yes") {
        videoFacultyHours = videoCount * lengthHours * typeFactor * comfortFactor * 0.55;
      } else if (hasComplexVideo && videoSupport === "no") {
        // The estimate assumes a simpler Panopto alternative instead of assigning
        // professional production work to the faculty member.
        videoFacultyHours = videoCount * lengthHours * 1.25 * comfortFactor;
      } else {
        videoFacultyHours = videoCount * lengthHours * Math.min(typeFactor, 1.25) * comfortFactor;
      }

      if (idStatus === "yes" && ["guidance", "substantial", "new", "unsure"].includes(a.panoptoComfort)) {
        videoFacultyHours *= 0.92;
      }
    }

    const visualBase = config.visualHours[a.visuals] || 0;
    let visualFacultyHours = visualBase;
    if (a.visuals === "several" && a.support.graphic === "yes") visualFacultyHours = visualBase * 0.3;
    if (a.visuals === "several" && a.support.graphic === "no") visualFacultyHours = 6;
    if (a.visuals === "several" && a.support.graphic === "unsure") visualFacultyHours = 8;
    if (a.visuals === "few" && a.support.graphic === "yes") visualFacultyHours = visualBase * 0.55;

    let interactionBase = 0;
    a.interactions.forEach((interaction) => {
      interactionBase += config.interactionHours[interaction] || 0;
    });
    let interactionFacultyHours = interactionBase;
    if (a.support.interactive === "yes") interactionFacultyHours = interactionBase * 0.28;
    if (a.support.interactive === "no") interactionFacultyHours = Math.min(interactionBase * 0.35, 10);
    if (a.support.interactive === "unsure") interactionFacultyHours = Math.min(interactionBase * 0.45, 14);
    if (idStatus === "yes") interactionFacultyHours *= 0.9;

    const likely = Math.max(8, designFacultyHours + videoFacultyHours + visualFacultyHours + interactionFacultyHours);
    const low = roundToFive(likely * config.facultyRange.low, "down");
    const high = roundToFive(likely * config.facultyRange.high, "up");
    const perModuleLow = Math.max(1, Math.round((low / modules) * 10) / 10);
    const perModuleHigh = Math.max(perModuleLow, Math.round((high / modules) * 10) / 10);

    const highDesignSignals =
      a.courseType === "lab" ||
      materialCounts.create >= 5 ||
      a.currentActivities.includes("lab") ||
      a.onlineActivities.some((item) => ["simulation", "game", "lab"].includes(item)) ||
      a.interactions.some((item) => ["scenario", "simulation", "game"].includes(item));

    let classification = "Mostly adapting existing materials";
    let classificationText = "Much of the course can likely be reorganized for online delivery while preserving the core structure and materials.";
    if (high >= 95 || highDesignSignals) {
      classification = "Substantial course redesign and development";
      classificationText = "Several parts of the learning experience will need to be rethought or newly developed for online students. Early instructional design consultation will be especially valuable.";
    } else if (high >= 50) {
      classification = "Moderate online-course development";
      classificationText = "The course has a useful foundation, but multiple activities, materials, or media elements will need adaptation for online delivery.";
    }

    const calendarWeeks = estimateWeeks(low, high, a.availability);
    const drivers = buildDrivers(a, materialCounts, videoFacultyHours, interactionBase);
    const supportRecommendations = buildSupportRecommendations(a, hasComplexVideo);
    const questions = buildQuestions(a, hasComplexVideo);
    const nextSteps = buildNextSteps(a, materialCounts, hasVideo);

    return {
      classification,
      classificationText,
      low,
      high,
      perModuleLow,
      perModuleHigh,
      calendarWeeks,
      drivers,
      supportRecommendations,
      questions,
      nextSteps,
    };
  }

  function roundToFive(value, direction) {
    if (direction === "down") return Math.max(5, Math.floor(value / 5) * 5);
    return Math.max(10, Math.ceil(value / 5) * 5);
  }

  function estimateWeeks(low, high, availability) {
    const range = ESTIMATION_CONFIG.weeklyCapacity[availability];
    if (!range) return null;
    const [weeklyLow, weeklyHigh] = range;
    return {
      low: Math.max(1, Math.ceil(low / weeklyHigh)),
      high: Math.max(1, Math.ceil(high / weeklyLow)),
    };
  }

  function buildDrivers(a, materialCounts, videoHours, interactionBase) {
    const drivers = [];
    if (materialCounts.create) drivers.push({ score: materialCounts.create * 4, text: `${materialCounts.create} course material${materialCounts.create === 1 ? "" : "s"} will need to be created.` });
    if (materialCounts.revise) drivers.push({ score: materialCounts.revise * 2, text: `${materialCounts.revise} existing material${materialCounts.revise === 1 ? " needs" : "s need"} revision.` });
    if (a.currentActivities.some((item) => ["hands_on", "demonstration", "lab"].includes(item))) drivers.push({ score: 18, text: "Hands-on work, demonstrations, or labs will need an intentional online alternative." });
    if (videoHours > 8) drivers.push({ score: videoHours, text: "The planned number or type of instructor-created videos adds preparation and recording time." });
    if (interactionBase > 15) drivers.push({ score: interactionBase, text: "The desired scenarios, simulations, or game-like activities may require design and development support." });
    if (a.activityFrequency === "several") drivers.push({ score: 14, text: "Students will complete several learning activities in each module." });
    if (a.support.id === "no") drivers.push({ score: 12, text: "Without an instructional designer, more planning and course-organization work may remain with the faculty member." });
    if (a.videoLength === "extra_long") drivers.push({ score: 10, text: "Longer planned videos generally require more preparation and editing." });
    if (!drivers.length) drivers.push({ score: 1, text: "Most selected materials and activities appear suitable for straightforward adaptation." });
    return drivers.sort((aItem, bItem) => bItem.score - aItem.score).slice(0, 5).map((item) => item.text);
  }

  function buildSupportRecommendations(a, hasComplexVideo) {
    const recommendations = [];
    const hasVideo = a.videoCadence && a.videoCadence !== "none";

    if (!hasVideo) {
      recommendations.push({ type: "panopto", title: "Panopto", text: "No instructor-created video is currently planned. Panopto remains available if a brief welcome, explanation, or demonstration would later be useful." });
    } else if (hasComplexVideo && a.support.video === "yes") {
      recommendations.push({ type: "panopto", title: "Panopto and video production", text: "Use Panopto for straightforward recordings and consult the videographer about the physical demonstrations, interviews, or location-based recordings you selected." });
    } else if (hasComplexVideo && a.support.video === "no") {
      recommendations.push({ type: "panopto", title: "A simpler Panopto approach", text: "Because a videographer is not available, consider adapting complex recordings into short Panopto explanations, screen demonstrations, or narrated slides." });
    } else {
      const helpText = ["new", "substantial", "guidance", "unsure"].includes(a.panoptoComfort)
        ? "Plan a brief Panopto orientation or test recording before producing the full set."
        : "Your planned recordings are a good fit for faculty-created Panopto videos.";
      recommendations.push({ type: "panopto", title: "Panopto", text: helpText });
    }

    if (a.support.id === "yes") recommendations.push({ title: "Instructional designer", text: "Work together on course organization, activity adaptation, assessment alignment, and a manageable production plan." });
    if (a.support.id === "no") recommendations.push({ title: "Instructional design", text: "Consider requesting at least an initial consultation, especially if in-person activities, new assessments, or custom media must be adapted." });
    if (a.support.id === "unsure") recommendations.push({ title: "Instructional designer", text: "Confirm whether an instructional designer is available and what parts of the process they can support." });

    if (a.visuals === "several" && a.support.graphic === "yes") recommendations.push({ title: "Graphic designer", text: "Discuss the original diagrams or illustrations early so content decisions and visual production can proceed together." });
    if (a.visuals === "several" && a.support.graphic !== "yes") recommendations.push({ title: "Visual approach", text: "Use existing visuals, appropriately licensed resources, or a simple reusable template unless graphic-design support becomes available." });

    const customInteractive = a.interactions.some((item) => ["scenario", "simulation", "game"].includes(item));
    if (customInteractive && a.support.interactive === "yes") recommendations.push({ title: "Interactivity designer", text: "Prioritize one or two interactions with the clearest learning purpose before expanding the scope." });
    if (customInteractive && a.support.interactive !== "yes") recommendations.push({ title: "Lower-lift interaction", text: "Consider whether a Canvas discussion, quiz, assignment, case analysis, or guided practice activity can meet the same objective." });

    return recommendations;
  }

  function buildQuestions(a, hasComplexVideo) {
    const questions = ["Which parts of the in-person experience are most important to preserve online?"];
    if (Object.values(a.materials).some((status) => ["create", "unsure"].includes(status))) questions.push("Which materials should be created first, and which could be simplified or replaced?");
    if (a.currentActivities.some((item) => ["groups", "hands_on", "demonstration", "lab"].includes(item))) questions.push("How could the selected group, hands-on, demonstration, or lab experiences work for students at a distance?");
    if (a.videoCadence !== "none") questions.push("Which topics genuinely need video, and which could be taught effectively through text, visuals, or activities?");
    if (hasComplexVideo) questions.push("Which proposed recordings need production support, and which could use a simpler Panopto format?");
    if (a.interactions.some((item) => ["scenario", "simulation", "game"].includes(item))) questions.push("What specific learning objective should each proposed scenario, simulation, or game-like activity address?");
    if (a.support.id === "unsure") questions.push("What instructional-design support is available, and what will the faculty member and ID each contribute?");
    return [...new Set(questions)].slice(0, 6);
  }

  function buildNextSteps(a, materialCounts, hasVideo) {
    const stepsList = ["Gather the current syllabus, assignments, presentation slides, and other materials in one place.", "Identify the two or three in-person experiences that are most important for student learning."];
    if (a.support.id !== "no") stepsList.push("Review this summary with your instructional designer and confirm the first development priorities.");
    else stepsList.push("Ask whether an instructional-design consultation is available before beginning the full conversion.");
    if (hasVideo) stepsList.push("Create one short Panopto test recording before planning or recording the entire video set.");
    if (materialCounts.create >= 4) stepsList.push("Choose one module as a prototype before creating the rest of the course.");
    if (a.interactions.some((item) => ["scenario", "simulation", "game"].includes(item))) stepsList.push("Compare the custom-interaction idea with a simpler Canvas alternative that addresses the same objective.");
    return [...new Set(stepsList)].slice(0, 5);
  }

  function renderResultsStep() {
    const results = state.results || calculateResults(state.answers);
    const title = state.answers.courseTitle ? ` for ${escapeHtml(state.answers.courseTitle)}` : "";
    const weeksText = results.calendarWeeks
      ? `At the weekly availability you selected, that is approximately ${results.calendarWeeks.low}–${results.calendarWeeks.high} weeks of faculty work. This does not include institutional scheduling or team wait time.`
      : "A calendar estimate is not shown because weekly availability was variable or uncertain.";

    return `
      <div class="results-header">
        <article class="result-summary">
          <p class="result-label">Course conversion snapshot${title}</p>
          <h3>${escapeHtml(results.classification)}</h3>
          <p>${escapeHtml(results.classificationText)}</p>
        </article>
        <article class="effort-card">
          <p class="result-label">Estimated faculty effort</p>
          <span class="effort-range">${results.low}–${results.high}</span>
          <p class="effort-meta">total preparation hours</p>
          <p class="effort-meta">About ${results.perModuleLow}–${results.perModuleHigh} hours per module</p>
        </article>
      </div>

      <div class="result-grid">
        <section class="result-section full-width">
          <p class="result-label">Recommended approach</p>
          <h3>How support could fit together</h3>
          <div class="support-recommendations">
            ${results.supportRecommendations
              .map((item) => `<div class="support-item ${item.type || ""}"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.text)}</span></div>`)
              .join("")}
          </div>
        </section>

        <section class="result-section">
          <p class="result-label">What shaped the estimate</p>
          <h3>Major effort drivers</h3>
          <ul>${results.drivers.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
        </section>

        <section class="result-section">
          <p class="result-label">Time perspective</p>
          <h3>Faculty availability</h3>
          <p>${escapeHtml(weeksText)}</p>
        </section>

        <section class="result-section">
          <p class="result-label">Bring to your consultation</p>
          <h3>Questions for your instructional designer</h3>
          <ul>${results.questions.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
        </section>

        <section class="result-section">
          <p class="result-label">Keep moving</p>
          <h3>Practical next steps</h3>
          <ol>${results.nextSteps.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ol>
        </section>

        <section class="result-section full-width">
          <p class="result-label">Use with context</p>
          <h3>Assumptions and limitations</h3>
          <p>This estimate is based on your responses and a set of adjustable planning assumptions. Actual effort will depend on the condition of the materials, available support, review cycles, institutional processes, and the final scope agreed upon with your instructional designer.</p>
          <p>The planner does not replace instructional-design consultation and is not a production commitment or formal workload assignment.</p>
          <details class="method-details">
            <summary>How was this estimate calculated?</summary>
            <div>
              <p>The planner combines a base amount for course planning and module development with estimates for revising or creating materials, adapting in-person activities, producing Panopto videos, and planning visuals or interactions.</p>
              <p>Specialist availability changes the faculty share of the work. When a specialist is unavailable, the estimate assumes an achievable lower-lift alternative instead of assigning professional production work to the faculty member. The displayed low-to-high range allows for variation among courses and materials.</p>
            </div>
          </details>
        </section>
      </div>
    `;
  }

  document.addEventListener("keydown", handleDialogEscape);
  render();
})();

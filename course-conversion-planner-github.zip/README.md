# Course Conversion Planner

This is a static, browser-based planning tool for faculty converting an in-person course to an online course. It asks faculty-friendly questions and produces:

- an estimated faculty-effort range;
- an approximate per-module estimate;
- a Panopto recommendation;
- suggested instructional design and production support;
- questions and next steps for an instructional designer consultation.

No responses are transmitted or permanently stored.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `app.js`, `.nojekyll`, and this README to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder, then save.

GitHub will display the public site address after the deployment finishes.

## Adjust the estimation assumptions

Open `app.js` and find the `ESTIMATION_CONFIG` object near the top of the file. It contains all baseline hours, multipliers, thresholds, and weekly-capacity ranges used by the calculator.

The included values are starter assumptions, not validated institutional workload standards. Calibrate them against completed course-conversion projects before presenting the estimate as an institutional norm.

## Change colors

Open `styles.css` and edit the custom properties at the top of the file. The interface does not use external fonts, frameworks, analytics, or remote services.
